<!doctype html>
<html lang="en-US">

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>Payment Receipt</title>
    <meta name="description" content="Payment Receipt.">
    <style type="text/css">
        a:hover {
            text-decoration: underline !important;
        }
        *{
            font-family: calibri;
        }
    </style>
</head>

<body style="margin: 0px;width: 100%;">
    <div class="width:940px;margin:20px auto">
        {!! @$mail_detail['message'] !!}
    </div>
</body>
</html>