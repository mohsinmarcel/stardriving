<!-- third party css -->
<link href="{{asset('assets/css/vendor/jquery-jvectormap-1.2.2.css')}}" rel="stylesheet" type="text/css" />
@stack('css')
<!-- third party css end -->
@stack('css')
<!-- App css -->
<link href="{{asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/app-custom.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('assets/css/app.min.css')}}" rel="stylesheet" type="text/css" id="light-style" />
<style>
    .form-control.is-invalid, .was-validated .form-control:invalid{
        background-image: none !important;
    }
</style>