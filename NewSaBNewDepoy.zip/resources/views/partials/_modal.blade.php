<!-- Modal -->
<div class="modal fade" id="frontPagesModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">
        <div id="modal-preloader" class="my-2">
          <div class="modal-preloader_status">
            <div class="modal-preloader_spinner">
              <div class="d-flex justify-content-center">
                <div class="spinner-border" role="status"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>