<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <script>document.write(new Date().getFullYear())</script> © Star Driving School Inc
            </div>
        </div>
    </div>
</footer>